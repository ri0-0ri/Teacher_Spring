package com.example.demo.domain;

import lombok.Data;

@Data
public class UserDTO {
	private String userid;
	private String userpw;
	private String username;
	private String usergender;
	private String zipcode;
	private String addr;
	private String addrdetail;
	private String addretc;
	private String userhobby;
}
