package com.example.demo.domain;

import lombok.Data;

@Data
public class FileDTO {
	private String systemname;
	private String orgname;
	private long boardnum;
}
